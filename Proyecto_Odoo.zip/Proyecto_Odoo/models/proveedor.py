from odoo import models, fields, api

class Proveedor(models.Model):
    _name = 'proyecto_odoo.proveedor'
    _description = 'Proveedor'

    name = fields.Char(string='Nombre', required=True)
    descripcion = fields.Text(string='Descripción')
    drive_folder_id = fields.Char(string="ID de Carpeta en Drive", required=True)
    plataforma_id = fields.Many2one('proyecto_odoo.plataforma', string='Plataforma', required=True)
    unidad_de_negocio_id = fields.Many2one('proyecto_odoo.unidad_de_negocio', string='Unidad de Negocio')
    archivo_ids = fields.One2many('proyecto_odoo.archivo', 'proveedor_id', string='Archivos')