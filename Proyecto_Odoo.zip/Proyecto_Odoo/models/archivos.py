from odoo import models, fields, api

class Archivo(models.Model):
    _name = 'proyecto_odoo.archivo'
    _description = 'Archivo'

    name = fields.Char(string='Nombre del Archivo', required=True)
    descripcion = fields.Text(string='Descripción')
    proveedor_id = fields.Many2one('proyecto_odoo.proveedor', string='Proveedor', required=True)
    file = fields.Binary(string='Archivo')