from odoo import models, fields, api



class DocsGenerados(models.Model):
    _name = 'proyecto_odoo.docs_generados'
    _description = 'Documentos Generados'

    name = fields.Char(string='Nombre', required=True)
    plataforma_id = fields.Many2one('proyecto_odoo.plataforma', string='Plataforma', required=True)
    file = fields.Binary(string='Archivo Generado')
    file_name = fields.Char(string='Nombre del Archivo')

