from odoo import models, fields, api

class UnidadDeNegocio(models.Model):
    _name = 'proyecto_odoo.unidad_de_negocio'
    _description = 'Unidad de Negocio'

    name = fields.Char(string='Nombre de la Unidad de Negocio', required=True)
    descripcion = fields.Text(string='Descripción')
    proveedor_ids = fields.One2many('proyecto_odoo.proveedor', 'unidad_de_negocio_id', string='Proveedores')
    plataforma_ids = fields.One2many('proyecto_odoo.plataforma', 'unidad_de_negocio_id', string='Plataformas')