from odoo import models, fields, api
import base64
import io
import magic
import openpyxl
import pandas as pd
import requests
from odoo.exceptions import UserError
from google_auth_oauthlib.flow import  InstalledAppFlow
import os
import google_auth_oauthlib.flow
from googleapiclient.discovery import build
import googleapiclient.errors
from google.oauth2.credentials import Credentials
from odoo.addons.test_import_export.tests.test_load import message
import logging
from google.oauth2.service_account import Credentials

_logger = logging.getLogger(__name__)

class Plataforma(models.Model):
    _name = 'proyecto_odoo.plataforma'
    _description = 'Plataforma'

    name = fields.Char(string='Nombre', required=True)
    descripcion = fields.Text(string='Descripción')
    tipo = fields.Selection([
        ('txd', 'TXD'),
        ('smk_mdh', 'SMK-MDH')
    ], string='Tipo de Plataforma', required=True)
    unidad_de_negocio_id = fields.Many2one('proyecto_odoo.unidad_de_negocio', string='Unidad de Negocio', required=True)
    proveedor_ids = fields.One2many('proyecto_odoo.proveedor', 'plataforma_id', string='Proveedores')
    docs_generados_ids = fields.One2many('proyecto_odoo.docs_generados', 'plataforma_id', string='Docs Generados')

    def get_drive_folder(self):
        self.ensure_one()  # Asegurar que solo se ejecuta en un solo registro

        # Ruta al archivo de credenciales
        creds_path = os.path.join(os.path.dirname(__file__), '..', 'credentials.json')
        creds = Credentials.from_service_account_file(creds_path, scopes=["https://www.googleapis.com/auth/drive"])
        service = build("drive", "v3", credentials=creds)

        # ID de la carpeta principal en Google Drive
        folder_id = '1Kt6OqSCi1pLRtK_fPRWbO1ksp0d8S_ka'

        # Obtener carpetas de proveedores
        query = f"'{folder_id}' in parents and mimeType = 'application/vnd.google-apps.folder'"
        results = service.files().list(q=query, fields="files(id, name)").execute()
        folders = results.get("files", [])

        for folder in folders:
            folder_name = folder['name']
            folder_id = folder['id']

            # Buscar o crear proveedor
            proveedor = self.env['proyecto_odoo.proveedor'].search([('drive_folder_id', '=', folder_id)], limit=1)
            if not proveedor:
                proveedor = self.env['proyecto_odoo.proveedor'].create({
                    'name': folder_name,
                    'drive_folder_id': folder_id,
                    'plataforma_id': self.id
                })
                _logger.info(f"Proveedor agregado: {folder_name} - ID: {folder_id}")
            else:
                _logger.info(f"Proveedor ya existente: {folder_name} - ID: {folder_id}")

            # Obtener archivos dentro del proveedor
            query_files = f"'{folder_id}' in parents and mimeType != 'application/vnd.google-apps.folder'"
            file_results = service.files().list(q=query_files, fields="files(id, name)").execute()
            files = file_results.get("files", [])

            for file in files:
                file_name = file['name']
                file_id = file['id']

                # Buscar si el archivo ya existe en Odoo
                archivo = self.env['proyecto_odoo.archivo'].search(
                    [('name', '=', file_name), ('proveedor_id', '=', proveedor.id)], limit=1)
                if not archivo:
                    # Descargar contenido del archivo desde Google Drive
                    request = service.files().get_media(fileId=file_id)
                    file_data = request.execute()  # Descarga el contenido del archivo
                    file_base64 = base64.b64encode(file_data).decode('utf-8')  # Convertir a base64

                    # Crear registro en Odoo con el archivo binario
                    self.env['proyecto_odoo.archivo'].create({
                        'name': file_name,
                        'proveedor_id': proveedor.id,
                        'file': file_base64  # Guardamos el archivo en formato binario
                    })
                    _logger.info(f"Archivo almacenado en Odoo: {file_name} - ID: {file_id}")
                else:
                    _logger.info(f"Archivo ya existente en Odoo: {file_name} - ID: {file_id}")

    def procesar_archivos_fichas(self):
        self.ensure_one()
        dataframes = []

        for proveedor in self.proveedor_ids:
            for archivo in proveedor.archivo_ids:
                if not archivo.file:
                    _logger.warning(f"El archivo {archivo.name} está vacío o no tiene datos.")
                    continue

                try:
                    archivo_bytes = base64.b64decode(archivo.file)
                    archivo_excel = io.BytesIO(archivo_bytes)
                    wb = openpyxl.load_workbook(archivo_excel, data_only=True)
                    sheet = wb.active

                    datos_extraidos = {"PROVEEDOR DE FICHA": proveedor.name}  # Agregar el proveedor de la ficha

                    for fila in sheet.iter_rows(min_row=1, max_row=10, values_only=True):
                        if fila[2] == "PRODUCT NAME":
                            datos_extraidos["PRODUCT NAME"] = fila[4]
                        elif fila[2] == "SUPPLIER NAME":
                            datos_extraidos["SUPPLIER NAME"] = fila[4]
                        elif fila[2] == "EAN 13":
                            datos_extraidos["EAN 13"] = fila[4]
                        elif fila[2] == "SKU":
                            datos_extraidos["SKU"] = fila[4]
                        elif fila[2] == "NET CONTENT (g, ml, cc, L, Kg)":
                            datos_extraidos["NET CONTENT"] = fila[4]

                    def obtener_material_y_submaterial(min_fila, max_fila):
                        max_valor = -float('inf')
                        fila_max = None
                        sub_material = ""

                        for fila_idx in range(min_fila, max_fila + 1):
                            for col_idx in range(5, 11):  # Columnas E a J
                                valor = sheet.cell(row=fila_idx, column=col_idx).value

                                if isinstance(valor, str):
                                    valor = valor.replace(',', '.').strip()
                                    if valor.replace('.', '').isdigit():
                                        valor = float(valor)
                                    else:
                                        valor = None

                                if valor is not None and isinstance(valor, (int, float)) and valor > max_valor:
                                    max_valor = valor
                                    fila_max = fila_idx

                        material_producto = ""
                        if fila_max:
                            if min_fila <= fila_max <= min_fila + 8:
                                material_producto = "PLASTIC"
                            elif min_fila + 9 <= fila_max <= min_fila + 12:
                                material_producto = "PAPER & CARDBOARD"
                            elif min_fila + 13 <= fila_max <= min_fila + 15:
                                material_producto = "METALS"
                            elif min_fila + 16 <= fila_max <= min_fila + 17:
                                material_producto = "GLASS"
                            elif fila_max == min_fila + 18:
                                material_producto = "WOOD"
                            elif fila_max == min_fila + 19:
                                material_producto = "OTHER"

                            sub_material = sheet.cell(row=fila_max, column=4).value or ""

                        return material_producto, sub_material

                    # Obtener Material y Sub Material del Producto Primario
                    material_producto, sub_material = obtener_material_y_submaterial(16, 35)
                    datos_extraidos["MATERIAL PRODUCTO PRIMARIO"] = material_producto
                    datos_extraidos["SUB MATERIAL PRIMARIO"] = sub_material

                    # Obtener Material y Sub Material del Producto Secundario
                    material_secundario, sub_material_secundario = obtener_material_y_submaterial(40, 59)
                    datos_extraidos["MATERIAL PRODUCTO SECUNDARIO"] = material_secundario
                    datos_extraidos["SUB MATERIAL SECUNDARIO"] = sub_material_secundario

                    _logger.info(f"Archivo: {archivo.name}, Material Producto Primario: {material_producto}, Sub Material Primario: {sub_material}")
                    _logger.info(f"Archivo: {archivo.name}, Material Producto Secundario: {material_secundario}, Sub Material Secundario: {sub_material_secundario}")

                    # Extraer el valor de la columna J en la fila 36
                    producto_por_envase = sheet.cell(row=36, column=10).value  # Columna J es la décima columna
                    datos_extraidos["PRODUCTO POR ENVASE"] = producto_por_envase if isinstance(producto_por_envase, (int, float)) else ""

                    if not datos_extraidos:
                        _logger.warning(f"El archivo {archivo.name} no contiene datos relevantes.")
                        continue

                    df = pd.DataFrame([datos_extraidos])
                    dataframes.append(df)

                except Exception as e:
                    _logger.error(f"Error procesando {archivo.name}: {str(e)}")

        if dataframes:
            try:
                resultado_df = pd.concat(dataframes, ignore_index=True)
                _logger.info(f"Número de filas en el DataFrame final: {len(resultado_df)}")

                if resultado_df.empty:
                    _logger.warning("El DataFrame final está vacío. No se generará archivo.")
                    return

                with io.BytesIO() as output:
                    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                        resultado_df.to_excel(writer, index=False, sheet_name='Datos Filtrados')
                    output.seek(0)

                    contenido_archivo = output.getvalue()
                    _logger.info(f"Tamaño del archivo generado: {len(contenido_archivo)} bytes")

                    if not contenido_archivo:
                        _logger.error("El archivo generado está vacío.")
                        return

                    self.env['proyecto_odoo.docs_generados'].create({
                        'name': f"Fichas_Extraidas_{self.name}.xlsx",
                        'plataforma_id': self.id,
                        'file': base64.b64encode(contenido_archivo)
                    })

                    _logger.info("Archivo de fichas extraídas procesado y guardado exitosamente.")

            except Exception as e:
                _logger.error(f"Error al generar el archivo consolidado: {str(e)}")
        else:
            _logger.warning("No se encontraron datos para generar el archivo.")

